package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    var num:Boolean=false

    var decimal:Boolean=false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun first(view: View){
        textView.append("1")
        num=true
    }
    fun second(view: View){
        textView.append("2")
        num=true
    }
    fun third(view: View){
        textView.append("3")
        num=true
    }
    fun fourth(view: View){
        textView.append("4")
        num=true
    }
    fun fifth(view: View){
        textView.append("5")
        num=true
    }
    fun sixth(view: View){
        textView.append("6")
        num=true
    }
    fun seventh(view: View){
        textView.append("7")
        num=true
    }
    fun eight(view: View){
        textView.append("8")
        num=true
    }
    fun ninth(view: View){
        textView.append("9")
        num=true
    }
    fun nil(view: View){
        textView.append("0")
        num=true
    }
    fun dot(view: View){
        if(num && !decimal){
            textView.append(".")
            decimal=true
        }
    }
    fun clearing(view: View){
        textView.text=""
        num=false
        decimal=false
    }
    fun onequal(view: View){
        if(num){
            var value =textView.text.toString()
            var prifix ="-"

            if(value.startsWith("-")){
                prifix ="-"
                value = value.substring(1)
            }

            if(value.contains("-")){
                val splitvalue = value.split("-")
                var one = splitvalue[0]
                var two = splitvalue[1]

                if(prifix.isEmpty()){
                    one = prifix + one
                }

                textView.text=(one.toDouble() - two.toDouble()).toString()
            }else if(value.contains("+")){
                val splitvalue = value.split("+")
                var one = splitvalue[0]
                var two = splitvalue[1]

                if(prifix.isEmpty()){
                    one = prifix + one
                }

                textView.text=(one.toDouble() + two.toDouble()).toString()
            }else if(value.contains("*")){
                val splitvalue = value.split("*")
                var one = splitvalue[0]
                var two = splitvalue[1]

                if(prifix.isEmpty()){
                    one = prifix + one
                }

                textView.text=(one.toDouble() * two.toDouble()).toString()
            }else if(value.contains("/")){
                val splitvalue = value.split("/")
                var one = splitvalue[0]
                var two = splitvalue[1]

                if(prifix.isEmpty()){
                    one = prifix + one
                }

                textView.text=(one.toDouble() / two.toDouble()).toString()
            }
        }
    }
    fun operators(view: View){
        if(num && !impersonated(textView.text.toString())){
            textView.append((view as Button).text)
            num = false
            decimal=false
        }
    }
    private fun impersonated(value:String):Boolean{
        return if(value.startsWith("-")){
            false
        }else{
            value.contains("/")||value.contains("*")||value.contains("-")
        }
    }


}